#include <bits/stdc++.h>

using namespace std;

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  
  int t;

  cin >> t;
  unsigned long long n;
  int r = 0;
  while(r < t){
    cin >> n;
    int i = 1, cont = 0;
    unsigned long long sum = 0;
    while (sum < n){
      sum += i*2+i;
      cont++;
      i++;
    }
    if((sum < n) || (sum > n && n == sum - (i-1))) cout << cont << "\n";
    else cout << cont-1 << "\n";
    r++;
  }

  return 0;
}