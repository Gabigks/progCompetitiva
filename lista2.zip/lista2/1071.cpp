#include <bits/stdc++.h>

#define IOS ios::sync_with_stdio(0),cin.tie(0)
using namespace std;
 
int main(){
    IOS;
    long long n;
    cin>>n;
    while(n--){
        int x,y;cin>>x>>y;
        int ly = max(x,y)-1,st = ly*ly;
        if(!(ly % 2)){
            if(y < ly+1)cout<<st+y<<endl;
            else cout<<(st+ly+1)+(ly+1-x)<<endl;
        }
        else{
            if(x < ly+1)cout<<st+x<<endl;
            else cout<<(st+ly+1)+(ly+1-y)<<endl;
        }
    }
    return 0;
}