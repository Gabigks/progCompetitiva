#include <bits/stdc++.h>

using namespace std;

int main(){

    ios::sync_with_stdio(0);
    cin.tie(0);
    
    long long r, le, ri;

    cin >> r;
    for(long long i=0; i<r; i++){
        cin >> le >> ri;
        if(le > ri){
            long long aux = le;
            le = ri;
            ri = aux;
        }
        if((le+ri)%3 == 0 && ri == le*2) cout << "YES" << "\n";
        else cout << "NO" << "\n";
    }

    return 0;
}